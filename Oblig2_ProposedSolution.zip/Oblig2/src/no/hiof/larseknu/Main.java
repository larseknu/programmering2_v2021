package no.hiof.larseknu;

import no.hiof.larseknu.model.Planet;
import no.hiof.larseknu.model.PlanetSystem;
import no.hiof.larseknu.model.Star;

public class Main {

    public static void main(String[] args) {
        Star theSun = new Star("Sun", 1, 1, 5777);

        PlanetSystem solarSystem = new PlanetSystem("Solar System", theSun);

        // Instansierer og legger planetene direkte til i planetsystemet
        solarSystem.addPlanet(new Planet("Mercury",0.03412549655905556, 1.7297154899894627E-4));
        solarSystem.addPlanet(new Planet("Venus", 0.08465003077267387, 0.002564278187565859));
        solarSystem.addPlanet(new Planet("Earth", 0.08911486599899289, 0.003146469968387777));
        solarSystem.addPlanet(new Planet("Mars", 0.04741089912158004, 3.3667017913593256E-4));
        solarSystem.addPlanet(new Planet("Jupiter",1.0, 1.0));
        solarSystem.addPlanet(new Planet("Saturn", 0.8145247020645666, 0.2994204425711275));
        solarSystem.addPlanet(new Planet("Uranus", 0.35475297935433336, 0.04573761854583773));
        solarSystem.addPlanet(new Planet("Neptune",0.34440217087226543, 0.05395152792413066));

        System.out.println(solarSystem);

        // Henter ut en referanse til hver planet
        Planet mercury = solarSystem.getPlanets().get(0);
        Planet venus = solarSystem.getPlanets().get(1);
        Planet earth = solarSystem.getPlanets().get(2);
        Planet mars = solarSystem.getPlanets().get(3);
        Planet jupiter = solarSystem.getPlanets().get(4);
        Planet saturn = solarSystem.getPlanets().get(5);
        Planet uranus = solarSystem.getPlanets().get(5);
        Planet neptune = solarSystem.getPlanets().get(7);

        System.out.println("First planet: " + mercury);
        System.out.println("Third planet: " + earth);

        System.out.printf("%s has a radius of %.2f km and a mass of %.3e kg %n", venus.getName(), venus.getRadiusInKm(), venus.getMassInKg());

        System.out.printf("%s has a radius of %.2f km and a mass of %.3e kg %n", saturn.getName(), saturn.getRadiusInKm(), saturn.getMassInKg());

        System.out.printf("%s has a radius of %.2f km and a mass of %.3e kg %n", theSun.getName(), theSun.getRadiusInKm(), theSun.getMassInKg());

        System.out.println("The surface gravity of " + saturn.getName() + " is " + saturn.getSurfaceGravity() + "m/s");
        System.out.println("The surface gravity of " + neptune.getName() + " is " + neptune.getSurfaceGravity() + "m/s");

        Planet smallestPlanet = solarSystem.getSmallestPlanet();
        Planet largestPlanet = solarSystem.getLargestPlanet();

        System.out.println(smallestPlanet.getName() + " is the smallest planet in the " + solarSystem.getName());
        System.out.println(largestPlanet.getName() + " is the largest planet in the " + solarSystem.getName());
    }
}
