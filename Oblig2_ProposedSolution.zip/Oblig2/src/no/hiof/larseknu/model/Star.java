package no.hiof.larseknu.model;

public class Star {
    private String name;
    private double radius;
    private double mass;
    private double effectiveTemp;

    public static final double SOLAR_RADIUS_IN_KM = 695700;
    public static final double SOLAR_MASS_IN_KG = 1.989E30;

    public Star(String name, double radius, double mass, double effectiveTemp) {
        this.name = name;
        this.radius = radius;
        this.mass = mass;
        this.effectiveTemp = effectiveTemp;
    }

    public double getMassInKg() {
        return mass * SOLAR_MASS_IN_KG;
    }

    public double getRadiusInKm() {
        return radius * SOLAR_RADIUS_IN_KM;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    public double getEffectiveTemp() {
        return effectiveTemp;
    }

    public void setEffectiveTemp(double effectiveTemp) {
        this.effectiveTemp = effectiveTemp;
    }

    @Override
    public String toString() {
        return String.format("%s has a radius of %f Rsun, a mass of %f Msun and a effective temperature of %.2fK", name, radius, mass, effectiveTemp);
    }
}
