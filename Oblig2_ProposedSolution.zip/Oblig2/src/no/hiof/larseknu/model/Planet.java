package no.hiof.larseknu.model;

public class Planet {
    private String name;
    private double radius;
    private double mass;

    public static final double JUPITER_MASS_IN_KG = 1.898E27;
    public static final double JUPITER_RADIUS_IN_KM = 	71492;
    public static final double GRAVITATIONAL_CONSTANT = 6.67408E-11;

    public Planet(String name, double radius, double mass) {
        this.name = name;
        this.radius = radius;
        this.mass = mass;
    }

    public double getSurfaceGravity() {
        return (GRAVITATIONAL_CONSTANT * getMassInKg()) / Math.pow(getRadiusInMeter(), 2);
    }

    private double getRadiusInMeter() {
        return getRadiusInKm() * 1000;
    }

    public double getMassInKg() {
        return mass * JUPITER_MASS_IN_KG;
    }

    public double getRadiusInKm() {
        return radius * JUPITER_RADIUS_IN_KM;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public double getMass() {
        return mass;
    }

    public void setMass(double mass) {
        this.mass = mass;
    }

    @Override
    public String toString() {
        return String.format("%s has a radius of %f Rjup and a mass of %f Mjup", name, radius, mass);
    }
}
